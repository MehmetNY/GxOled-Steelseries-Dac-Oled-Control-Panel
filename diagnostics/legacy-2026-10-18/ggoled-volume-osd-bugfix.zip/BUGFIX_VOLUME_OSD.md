# Volume OSD flicker fix

## What changed

`ggoled_draw/src/lib.rs` now drains HID/device events before sending the next OLED frame. When the base station reports `DeviceEvent::Volume`, the renderer yields display writes for 2.5 seconds after the most recent volume-dial event. This leaves the base station's native volume overlay in control of the OLED instead of letting ggoled overwrite it mid-animation.

The existing layer map is not cleared or rebuilt by this behavior. Clock and media layers remain loaded; GIF playback pauses its frame advancement while the native volume OSD is active and resumes automatically afterward.

## Build on Windows PowerShell

1. Extract the source ZIP to a folder. Open PowerShell in the folder containing the root `Cargo.toml`.
2. Close other running copies of ggoled first, so multiple processes cannot write to the same OLED:

   ```powershell
   Get-Process ggoled_app -ErrorAction SilentlyContinue | Stop-Process -Force
   ```

3. Check the Rust project:

   ```powershell
   cargo check -p ggoled_app
   ```

4. Build the release executable with SDL3 compiled from source (the same feature that worked on this PC before):

   ```powershell
   cargo build --release -p ggoled_app --features sdl3-static
   ```

5. Run the executable:

   ```powershell
   .\target\release\ggoled_app.exe
   ```

The executable is at `target\release\ggoled_app.exe`. The build output is local to this source folder.

## Test

1. Start ggoled and verify the clock/GIF works normally.
2. Rotate the base station's volume dial repeatedly. Its native volume screen should appear without ggoled sending competing display frames.
3. Stop moving the dial. ggoled should resume after about 2.5 seconds from the last volume event.
4. Repeat with GIF playback enabled.

## Verification limitation

This environment does not have the Rust toolchain, so this source change could not be compiled here. The previous version compiled on the user's Windows machine; run `cargo check` and `cargo build` above to verify the new source locally.
